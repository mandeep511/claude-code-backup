# Model Architecture Overview

## Introduction

This document provides a comprehensive overview of the model selection and conversation management system in OpenAGI. The system is designed to integrate with various AI model providers while maintaining a consistent conversation interface for users.

## System Components

The architecture consists of several key components:

1. **Model Configuration** - Defines available models and their settings
2. **API Key Management** - Securely handles authentication with model providers
3. **Client Initialization** - Creates and manages provider-specific clients
4. **Conversation Management** - Handles message flow and maintains conversation state
5. **UI Components** - Allows users to configure and interact with models

## High-Level Architecture

```mermaid
graph TD
    User[User] --> UI[UI Components]
    UI --> Config[Model Configuration]
    Config --> Client[Client Initialization]
    Client --> ModelAPI[Model API Clients]
    
    ModelAPI -- Anthropic --> AnthropicAPI[Anthropic API]
    ModelAPI -- Bedrock --> BedrockAPI[AWS Bedrock]
    ModelAPI -- Vertex --> VertexAPI[Google Vertex AI]
    
    UI --> Query[Query Engine]
    Query --> Conversation[Conversation Manager]
    Conversation --> ModelAPI
    
    subgraph "Model Selection"
        Config
        Client
        ModelAPI
    end
    
    subgraph "Conversation Flow"
        Query
        Conversation
    end
```

## Directory Structure

The code related to the model architecture is primarily located in:

- `src/utils/model.ts` - Model configuration and selection
- `src/utils/config.ts` - Configuration management including API keys
- `src/services/claude.ts` - Anthropic client initialization and API communication
- `src/query.ts` - Conversation flow and management

## Key Integration Points

The system integrates with several external libraries:

- `@anthropic-ai/sdk` - Main package for communicating with Anthropic models
- `@anthropic-ai/bedrock-sdk` - For AWS Bedrock integration 
- `@anthropic-ai/vertex-sdk` - For Google Vertex AI integration

## Related Documentation

- [Model Selection](./model-selection.md) - Details about model configuration and selection
- [Conversation Flow](./conversation-flow.md) - Overview of the conversation management system
- [API Integration](./api-integration.md) - Information about third-party API integration
- [Developer Quick Reference](./developer-reference.md) - Quick guide for developers 