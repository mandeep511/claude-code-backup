# Model Selection

This document details the model selection system in OpenAGI, including configuration, API key management, and client initialization.

## Model Configuration

Model configuration is primarily handled in `src/utils/model.ts`. The system supports three different providers:

1. **Anthropic Direct API** - Default option using Anthropic's API directly
2. **AWS Bedrock** - Integration with AWS Bedrock service
3. **Google Vertex AI** - Integration with Google Vertex AI

### Provider Selection

Provider selection is controlled by environment variables:

```typescript
export const USE_BEDROCK = !!process.env.CLAUDE_CODE_USE_BEDROCK
export const USE_VERTEX = !!process.env.CLAUDE_CODE_USE_VERTEX
```

### Model Configuration Structure

Models are configured using a standard format:

```typescript
export interface ModelConfig {
  bedrock: string
  vertex: string
  firstParty: string
}

const DEFAULT_MODEL_CONFIG: ModelConfig = {
  bedrock: 'us.anthropic.claude-3-7-sonnet-20250219-v1:0',
  vertex: 'claude-3-7-sonnet@20250219',
  firstParty: 'claude-3-7-sonnet-20250219',
}
```

### Model Selection Logic

The `getSlowAndCapableModel` function determines which model to use:

```mermaid
flowchart TD
    Start([Start]) --> CheckUserType{Is User Type 'ant'?}
    CheckUserType -- Yes --> CheckEnvModel{Is ANTHROPIC_MODEL set?}
    CheckUserType -- No --> CheckSWEBench{Is User Type 'SWE_BENCH'?}
    
    CheckEnvModel -- Yes --> ReturnEnvModel[Return ANTHROPIC_MODEL]
    CheckEnvModel -- No --> GetExperimentValue[Get Experiment Value]
    
    CheckSWEBench -- Yes --> CheckSWEBenchEnv{Is ANTHROPIC_MODEL set?}
    CheckSWEBench -- No --> GetModelConfig[Get Model Config]
    
    CheckSWEBenchEnv -- Yes --> ReturnSWEBenchEnv[Return ANTHROPIC_MODEL]
    CheckSWEBenchEnv -- No --> GetModelConfig
    
    GetModelConfig --> CheckBedrock{Is USE_BEDROCK true?}
    CheckBedrock -- Yes --> ReturnBedrock[Return config.bedrock]
    CheckBedrock -- No --> CheckVertex{Is USE_VERTEX true?}
    
    CheckVertex -- Yes --> ReturnVertex[Return config.vertex]
    CheckVertex -- No --> ReturnFirstParty[Return config.firstParty]
    
    ReturnEnvModel --> End([End])
    GetExperimentValue --> End
    ReturnSWEBenchEnv --> End
    ReturnBedrock --> End
    ReturnVertex --> End
    ReturnFirstParty --> End
```

## API Key Management

API key management is handled in `src/utils/config.ts` through the `getAnthropicApiKey` function.

### API Key Retrieval Flow

```mermaid
flowchart TD
    Start([Start]) --> GetConfig[Get Global Config]
    GetConfig --> CheckUserType{Is User Type 'SWE_BENCH'?}
    
    CheckUserType -- Yes --> ReturnOverride[Return ANTHROPIC_API_KEY_OVERRIDE]
    CheckUserType -- No --> CheckAnt{Is User Type 'ant'?}
    
    CheckAnt -- Yes --> CheckAntKey{Is ANTHROPIC_API_KEY set?}
    CheckAnt -- No --> CheckConfigKey{Is config.apiKey set?}
    
    CheckAntKey -- Yes --> CheckApproved{Is Key in approved list?}
    CheckAntKey -- No --> CheckConfigKey
    
    CheckApproved -- Yes --> ReturnAntKey[Return ANTHROPIC_API_KEY]
    CheckApproved -- No --> CheckConfigKey
    
    CheckConfigKey -- Yes --> ReturnConfigKey[Return config.apiKey]
    CheckConfigKey -- No --> CheckPrimaryKey{Is config.primaryApiKey set?}
    
    CheckPrimaryKey -- Yes --> ReturnPrimaryKey[Return config.primaryApiKey]
    CheckPrimaryKey -- No --> CheckEnvKey{Is ANTHROPIC_API_KEY set and approved?}
    
    CheckEnvKey -- Yes --> ReturnEnvKey[Return ANTHROPIC_API_KEY]
    CheckEnvKey -- No --> ReturnNull[Return null]
    
    ReturnOverride --> End([End])
    ReturnAntKey --> End
    ReturnConfigKey --> End
    ReturnPrimaryKey --> End
    ReturnEnvKey --> End
    ReturnNull --> End
```

## Client Initialization

The Anthropic client is initialized in `src/services/claude.ts` through the `getAnthropicClient` function.

### Client Types

Depending on the selected provider, one of three client types is initialized:

1. **AnthropicBedrock** - For AWS Bedrock integration
2. **AnthropicVertex** - For Google Vertex AI integration
3. **Anthropic** - For direct Anthropic API access

### Client Initialization Flow

```mermaid
flowchart TD
    Start([Start]) --> CheckExisting{Does anthropicClient exist?}
    CheckExisting -- Yes --> ReturnExisting[Return existing client]
    CheckExisting -- No --> GetRegion[Get region for model]
    
    GetRegion --> SetupHeaders[Setup default headers]
    SetupHeaders --> CheckBedrock{Is USE_BEDROCK true?}
    
    CheckBedrock -- Yes --> CreateBedrock[Create AnthropicBedrock client]
    CheckBedrock -- No --> CheckVertex{Is USE_VERTEX true?}
    
    CheckVertex -- Yes --> CreateVertex[Create AnthropicVertex client]
    CheckVertex -- No --> GetApiKey[Get Anthropic API Key]
    
    GetApiKey --> CheckApiKey{Is API Key valid?}
    CheckApiKey -- Yes --> CreateAnthropicClient[Create Anthropic client]
    CheckApiKey -- No --> LogError[Log error for ANT users]
    LogError --> CreateAnthropicClient
    
    CreateBedrock --> SaveClient[Save client reference]
    CreateVertex --> SaveClient
    CreateAnthropicClient --> SaveClient
    
    SaveClient --> ReturnClient[Return client]
    ReturnExisting --> End([End])
    ReturnClient --> End
```

## User Interface for Model Selection

The model selection interface is provided through two main components:

1. **ModelConfigStep** (`src/components/ModelConfigStep.tsx`) - Handles model selection during onboarding
2. **Config** (`src/components/Config.tsx`) - Allows changing model settings after initial setup

### Available Models

The system currently supports these predefined models:

```typescript
const MODEL_OPTIONS = [
  { label: 'Claude 3.7 Sonnet', value: 'claude-3-7-sonnet-20250219' },
  { label: 'Claude 3.5 Haiku', value: 'claude-3-5-haiku-20241022' },
]
```

## Configuration Storage

Model configuration is stored in the global configuration object:

```typescript
export type GlobalConfig = {
  // ...other properties
  modelName?: string // The AI model to use
  apiKey?: string // The API key for the selected model
  // ...other properties
}
``` 