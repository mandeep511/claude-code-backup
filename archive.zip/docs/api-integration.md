# API Integration

This document details how the OpenAGI system integrates with external APIs and provides guidance on extending it to support additional models.

## Current API Integrations

The system currently integrates with the following APIs:

1. **Anthropic API** - Direct integration with Anthropic's Claude models
2. **AWS Bedrock** - Integration with Anthropic models via AWS Bedrock
3. **Google Vertex AI** - Integration with Anthropic models via Google Vertex AI

## API Client Libraries

The system uses the following client libraries:

```typescript
import '@anthropic-ai/sdk/shims/node'
import Anthropic, { APIConnectionError, APIError } from '@anthropic-ai/sdk'
import { AnthropicBedrock } from '@anthropic-ai/bedrock-sdk'
import { AnthropicVertex } from '@anthropic-ai/vertex-sdk'
```

## Authentication Configuration

Different authentication methods are used depending on the provider:

### Anthropic Direct API

```typescript
// Authentication via API key
anthropicClient = new Anthropic({
  apiKey, // From getAnthropicApiKey()
  dangerouslyAllowBrowser: true,
  ...ARGS,
})
```

### AWS Bedrock

```typescript
// Uses AWS SDK credentials
const client = new AnthropicBedrock(ARGS)
```

### Google Vertex AI

```typescript
// Uses Google Cloud authentication
const vertexArgs = {
  ...ARGS,
  region: region || process.env.CLOUD_ML_REGION || 'us-east5',
}
const client = new AnthropicVertex(vertexArgs)
```

## API Communication Flow

```mermaid
sequenceDiagram
    participant App
    participant Client as Anthropic Client
    participant API as Model API
    
    App->>Client: Prepare messages & tools
    App->>Client: Call messages.stream()
    Client->>API: Send API request
    API->>Client: Stream response chunks
    Client->>App: Process stream events
    App->>App: Handle final response
```

## Common API Interface

Despite using different providers, the system maintains a common interface for API communication:

```typescript
const s = anthropic.beta.messages.stream(
  {
    model: options.model,
    max_tokens: Math.max(
      maxThinkingTokens + 1,
      getMaxTokensForModel(options.model),
    ),
    messages: addCacheBreakpoints(messages),
    temperature: MAIN_QUERY_TEMPERATURE,
    system,
    tools: toolSchemas,
    ...(useBetas ? { betas } : {}),
    metadata: getMetadata(),
    ...(process.env.USER_TYPE === 'ant' && maxThinkingTokens > 0
      ? {
          thinking: {
            budget_tokens: maxThinkingTokens,
            type: 'enabled',
          },
        }
      : {}),
  },
  { signal },
)
```

## Key API Integration Points

The main integration points for model APIs are:

1. **Client Initialization** - `getAnthropicClient()` in `src/services/claude.ts`
2. **API Communication** - `querySonnetWithPromptCaching()` in `src/services/claude.ts`
3. **Model Selection** - `getSlowAndCapableModel()` in `src/utils/model.ts`
4. **Authentication** - `getAnthropicApiKey()` in `src/utils/config.ts`

## Extending for New Models

To extend the system for new models or providers, the following steps are necessary:

### 1. Update Model Configuration

Modify the `ModelConfig` interface and `DEFAULT_MODEL_CONFIG` in `src/utils/model.ts`:

```typescript
export interface ModelConfig {
  bedrock: string
  vertex: string
  firstParty: string
  newProvider: string  // Add new provider
}

const DEFAULT_MODEL_CONFIG: ModelConfig = {
  bedrock: 'us.anthropic.claude-3-7-sonnet-20250219-v1:0',
  vertex: 'claude-3-7-sonnet@20250219',
  firstParty: 'claude-3-7-sonnet-20250219',
  newProvider: 'model-name-for-new-provider',  // Add default model
}
```

### 2. Add Provider Detection

Add environment variables to detect the new provider:

```typescript
export const USE_BEDROCK = !!process.env.CLAUDE_CODE_USE_BEDROCK
export const USE_VERTEX = !!process.env.CLAUDE_CODE_USE_VERTEX
export const USE_NEW_PROVIDER = !!process.env.USE_NEW_PROVIDER  // Add new flag
```

### 3. Update Model Selection Logic

Modify the `getSlowAndCapableModel` function to include the new provider:

```typescript
export const getSlowAndCapableModel = memoize(async (): Promise<string> => {
  // ... existing user type checks ...

  const config = await getModelConfig()
  if (USE_BEDROCK) {
    return config.bedrock
  }
  if (USE_VERTEX) {
    return config.vertex
  }
  if (USE_NEW_PROVIDER) {  // Add new provider check
    return config.newProvider
  }
  return config.firstParty
})
```

### 4. Add Client Initialization

Update the `getAnthropicClient` function to initialize the new provider's client:

```typescript
export function getAnthropicClient(model?: string): Anthropic {
  if (anthropicClient) {
    return anthropicClient
  }
  
  // ... existing setup code ...
  
  if (USE_BEDROCK) {
    const client = new AnthropicBedrock(ARGS)
    anthropicClient = client
    return client
  }
  if (USE_VERTEX) {
    const vertexArgs = { /* ... vertex args ... */ }
    const client = new AnthropicVertex(vertexArgs)
    anthropicClient = client
    return client
  }
  if (USE_NEW_PROVIDER) {  // Add new provider
    const newProviderArgs = { /* ... provider-specific args ... */ }
    const client = new NewProviderClient(newProviderArgs)
    anthropicClient = client
    return client
  }
  
  // ... existing Anthropic direct API code ...
}
```

### 5. Update UI Components

Update the model options in UI components:

```typescript
// In src/components/ModelConfigStep.tsx
const MODEL_OPTIONS = [
  { label: 'Claude 3.7 Sonnet', value: 'claude-3-7-sonnet-20250219' },
  { label: 'Claude 3.5 Haiku', value: 'claude-3-5-haiku-20241022' },
  { label: 'New Provider Model', value: 'new-provider-model' },  // Add new model
]

// Similar updates in src/components/Config.tsx
```

### 6. Handle API Responses

If the new provider returns responses in a different format, add conversion logic in `querySonnetWithPromptCaching`:

```typescript
// Example adapter for new provider responses
function adaptNewProviderResponse(response) {
  return {
    id: response.id || randomUUID(),
    content: convertNewProviderContent(response.content),
    role: 'assistant',
    model: response.model,
    stop_reason: response.stop_reason,
    type: 'message',
    usage: convertNewProviderUsage(response.usage),
  }
}
```

## Adapter Pattern Implementation

For providers with significantly different APIs, implement an adapter pattern:

```typescript
class GenericModelAdapter {
  constructor(client) {
    this.client = client
  }

  async stream(options, config) {
    // Implement provider-specific streaming
  }
  
  // Other methods to match the Anthropic API interface
}

// Wrap different provider clients in the adapter
if (USE_NEW_PROVIDER) {
  const rawClient = new NewProviderClient(newProviderArgs)
  anthropicClient = new GenericModelAdapter(rawClient)
  return anthropicClient
}
```

## Environment Variables for Providers

Different providers require different environment variables:

```
# Direct Anthropic API
ANTHROPIC_API_KEY=key_xxxxxxxxxxxx

# AWS Bedrock
CLAUDE_CODE_USE_BEDROCK=1
# Plus standard AWS credentials via ~/.aws/credentials

# Google Vertex AI 
CLAUDE_CODE_USE_VERTEX=1
ANTHROPIC_VERTEX_PROJECT_ID=your-gcp-project-id
VERTEX_REGION_CLAUDE_3_7_SONNET=us-east5
# Plus standard GCP authentication

# New Provider Example
USE_NEW_PROVIDER=1
NEW_PROVIDER_API_KEY=key_xxxxxxxxxxxx
``` 