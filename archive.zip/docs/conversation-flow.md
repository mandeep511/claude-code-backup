# Conversation Flow

This document details the conversation management system in OpenAGI, including query handling, message processing, and state management.

## Overview

The conversation flow is primarily managed by the `query` function in `src/query.ts`. This function coordinates the interaction between the user, the AI model, and any tools that might be used during the conversation.

## Message Types

The system uses several types of messages:

```typescript
// User messages
export type UserMessage = {
  message: MessageParam
  type: 'user'
  uuid: UUID
  toolUseResult?: FullToolUseResult
}

// Assistant messages
export type AssistantMessage = {
  costUSD: number
  durationMs: number
  message: APIAssistantMessage
  type: 'assistant'
  uuid: UUID
  isApiErrorMessage?: boolean
}

// Progress messages (for tool use)
export type ProgressMessage = {
  content: AssistantMessage
  normalizedMessages: NormalizedMessage[]
  siblingToolUseIDs: Set<string>
  tools: Tool[]
  toolUseID: string
  type: 'progress'
  uuid: UUID
}

// Combined message type
export type Message = UserMessage | AssistantMessage | ProgressMessage
```

## Conversation Flow Diagram

```mermaid
sequenceDiagram
    participant User
    participant Query as Query Engine
    participant Model as AI Model
    participant Tool as Tool System
    
    User->>Query: Send user message
    Query->>Query: Format system prompt
    Query->>Model: Send messages & context
    Model->>Query: Return assistant message
    
    alt Message contains tool_use
        Query->>Tool: Process tool use request
        
        alt Tool requires user permission
            Tool->>User: Request permission
            User->>Tool: Grant/deny permission
        end
        
        Tool->>Query: Return tool results
        Query->>Model: Send tool results
        Model->>Query: Return follow-up response
    end
    
    Query->>User: Display assistant message
```

## Query Function

The main `query` function is an async generator that yields messages as they are processed:

```typescript
export async function* query(
  messages: Message[],
  systemPrompt: string[],
  context: { [k: string]: string },
  canUseTool: CanUseToolFn,
  toolUseContext: ToolUseContext,
  getBinaryFeedbackResponse?: (
    m1: AssistantMessage,
    m2: AssistantMessage,
  ) => Promise<BinaryFeedbackResult>,
): AsyncGenerator<Message, void> {
  // ... implementation
}
```

## Query Process Flow

```mermaid
flowchart TD
    Start([Start]) --> FormatPrompt[Format system prompt with context]
    FormatPrompt --> GetResponse[Get assistant response]
    GetResponse --> CheckBinaryFeedback{Use binary feedback?}
    
    CheckBinaryFeedback -- Yes --> GetTwoResponses[Get two responses]
    CheckBinaryFeedback -- No --> ProcessResponse[Process single response]
    
    GetTwoResponses --> CompareBinary[Compare and select best response]
    CompareBinary --> ProcessResponse
    
    ProcessResponse --> CheckToolUse{Contains tool_use?}
    
    CheckToolUse -- No --> ReturnResponse[Return response]
    CheckToolUse -- Yes --> CheckToolType{Are all tools read-only?}
    
    CheckToolType -- Yes --> RunConcurrently[Run tools concurrently]
    CheckToolType -- No --> RunSerially[Run tools serially]
    
    RunConcurrently --> CollectResults[Collect tool results]
    RunSerially --> CollectResults
    
    CollectResults --> RecursiveQuery[Query with tool results]
    RecursiveQuery --> ReturnResponse
    
    ReturnResponse --> End([End])
```

## Tool Use Processing

Tool use is handled by separate functions that manage the execution of tools and processing of results:

### Tool Execution Flow

```mermaid
flowchart TD
    Start([Start]) --> FindTool[Find requested tool]
    FindTool --> CheckToolExists{Tool exists?}
    
    CheckToolExists -- No --> ReturnError[Return tool not found error]
    CheckToolExists -- Yes --> ValidateInput[Validate tool input]
    
    ValidateInput --> CheckValidInput{Input valid?}
    CheckValidInput -- No --> ReturnValidationError[Return validation error]
    CheckValidInput -- Yes --> CheckPermission[Check tool use permission]
    
    CheckPermission --> HasPermission{Has permission?}
    HasPermission -- No --> ReturnPermissionError[Return permission denied]
    HasPermission -- Yes --> ExecuteTool[Execute tool]
    
    ExecuteTool --> YieldResults[Yield tool results]
    
    ReturnError --> End([End])
    ReturnValidationError --> End
    ReturnPermissionError --> End
    YieldResults --> End
```

## Binary Feedback System

For ANT users, the system can generate two alternative responses and choose the better one:

```mermaid
flowchart TD
    Start([Start]) --> CheckEnabled{Is binary feedback enabled?}
    
    CheckEnabled -- No --> GetSingleResponse[Get single response]
    CheckEnabled -- Yes --> GetTwoResponses[Get two responses]
    
    GetTwoResponses --> CheckErrors{Any API errors?}
    CheckErrors -- Yes --> UseNonError[Use non-error response]
    CheckErrors -- No --> CheckValid{Are responses valid for comparison?}
    
    CheckValid -- No --> UseFirstResponse[Use first response]
    CheckValid -- Yes --> CompareResponses[Compare responses]
    
    CompareResponses --> SelectBetter[Select better response]
    
    GetSingleResponse --> ReturnResponse[Return response]
    UseNonError --> ReturnResponse
    UseFirstResponse --> ReturnResponse
    SelectBetter --> ReturnResponse
    
    ReturnResponse --> End([End])
```

## API Communication

Communication with the AI model is handled by the `querySonnet` function in `src/services/claude.ts`:

```typescript
export async function querySonnet(
  messages: (UserMessage | AssistantMessage)[],
  systemPrompt: string[],
  maxThinkingTokens: number,
  tools: Tool[],
  signal: AbortSignal,
  options: {
    dangerouslySkipPermissions: boolean
    model: string
    prependCLISysprompt: boolean
  },
): Promise<AssistantMessage> {
  // ... implementation
}
```

### API Communication Flow

```mermaid
flowchart TD
    Start([Start]) --> GetClient[Get Anthropic client]
    GetClient --> PrepareSysPrompt[Prepare system prompt]
    PrepareSysPrompt --> PrepareTools[Prepare tool schemas]
    PrepareTools --> SendRequest[Send streaming request]
    
    SendRequest --> MonitorStream[Monitor stream]
    MonitorStream --> CheckSignal{Signal aborted?}
    
    CheckSignal -- Yes --> CancelRequest[Cancel request]
    CheckSignal -- No --> ProcessResponse[Process response]
    
    ProcessResponse --> CalculateCost[Calculate cost]
    CalculateCost --> ReturnMessage[Return assistant message]
    
    CancelRequest --> ReturnInterruption[Return interruption message]
    
    ReturnMessage --> End([End])
    ReturnInterruption --> End
```

## Message Normalization

Messages are normalized before being sent to the API through the `normalizeMessagesForAPI` function in `src/utils/messages.js`:

```typescript
export function normalizeMessagesForAPI(
  messages: Message[],
): (UserMessage | AssistantMessage)[] {
  // ... implementation
}
```

## Thinking Mechanism

The system includes a special "thinking" mechanism with specific rules:

1. A message with a thinking block must be part of a query with `max_thinking_length > 0`
2. A thinking block cannot be the last message in a block
3. Thinking blocks must be preserved for the duration of an assistant trajectory

## Error Handling

Errors are handled at various levels:

1. **API Errors** - Converted to assistant messages with error information
2. **Tool Use Errors** - Returned as tool results with error flags
3. **Validation Errors** - Caught and reported before tool execution

## Tool Use Context

The tool use context provides the environment for tool execution, including:

- Available tools
- Maximum thinking tokens
- Model information
- Abort controller for cancellation
- Permissions settings 