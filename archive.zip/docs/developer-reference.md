# Developer Quick Reference

This document provides a quick reference for developers working with the OpenAGI model and conversation system.

## Key Files

| File | Description |
|------|-------------|
| `src/utils/model.ts` | Model configuration and selection logic |
| `src/utils/config.ts` | Configuration management including API keys |
| `src/services/claude.ts` | Anthropic client initialization and API communication |
| `src/query.ts` | Conversation flow and management |
| `src/components/ModelConfigStep.tsx` | UI for model selection during onboarding |
| `src/components/Config.tsx` | UI for changing model settings |

## Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `ANTHROPIC_API_KEY` | Anthropic API key | `key_xxxxxxxxxxxx` |
| `ANTHROPIC_MODEL` | Override model selection | `claude-3-7-sonnet-20250219` |
| `CLAUDE_CODE_USE_BEDROCK` | Use AWS Bedrock | `1` |
| `CLAUDE_CODE_USE_VERTEX` | Use Google Vertex AI | `1` |
| `ANTHROPIC_VERTEX_PROJECT_ID` | GCP Project ID for Vertex AI | `my-gcp-project` |
| `VERTEX_REGION_CLAUDE_3_7_SONNET` | Region for Vertex AI model | `us-east5` |

## Model Configuration

```typescript
// Default model configuration
const DEFAULT_MODEL_CONFIG: ModelConfig = {
  bedrock: 'us.anthropic.claude-3-7-sonnet-20250219-v1:0',
  vertex: 'claude-3-7-sonnet@20250219',
  firstParty: 'claude-3-7-sonnet-20250219',
}

// Small fast model for less intensive tasks
export const SMALL_FAST_MODEL = USE_BEDROCK
  ? 'us.anthropic.claude-3-5-haiku-20241022-v1:0'
  : USE_VERTEX
    ? 'claude-3-5-haiku@20241022'
    : 'claude-3-5-haiku-20241022'
```

## Message Types

| Type | Purpose |
|------|---------|
| `UserMessage` | Represents a message from the user |
| `AssistantMessage` | Represents a response from the AI model |
| `ProgressMessage` | Represents intermediate progress during tool execution |

## Common Code Patterns

### Getting the Anthropic Client

```typescript
import { getAnthropicClient } from '../services/claude.js'

// Get client with optional model hint for region selection
const anthropic = await getAnthropicClient(modelName)
```

### Getting the Current Model

```typescript
import { getSlowAndCapableModel } from '../utils/model.js'

// Get the current model name
const modelName = await getSlowAndCapableModel()
```

### Making a Query to the Model

```typescript
import { querySonnet } from '../services/claude.js'

const response = await querySonnet(
  messages,
  systemPrompt,
  maxThinkingTokens,
  tools,
  abortController.signal,
  {
    dangerouslySkipPermissions: false,
    model: await getSlowAndCapableModel(),
    prependCLISysprompt: true,
  },
)
```

### Managing the Conversation Flow

```typescript
import { query } from '../query.js'

// Create an async iterator for conversation flow
const conversationFlow = query(
  messages,
  systemPrompt,
  context,
  canUseTool,
  toolUseContext,
)

// Process messages as they come
for await (const message of conversationFlow) {
  // Handle each message
  console.log(message.type)
}
```

## Cost Calculation

```typescript
// Cost per million tokens for Claude 3.7 Sonnet
const SONNET_COST_PER_MILLION_INPUT_TOKENS = 3
const SONNET_COST_PER_MILLION_OUTPUT_TOKENS = 15

// Calculate cost in USD
const costUSD =
  (inputTokens / 1_000_000) * SONNET_COST_PER_MILLION_INPUT_TOKENS +
  (outputTokens / 1_000_000) * SONNET_COST_PER_MILLION_OUTPUT_TOKENS
```

## Adding a New Provider

### 1. Update Model Config

```typescript
// In src/utils/model.ts
export interface ModelConfig {
  bedrock: string
  vertex: string
  firstParty: string
  newProvider: string  // Add new provider
}
```

### 2. Update Provider Detection

```typescript
// In src/utils/model.ts
export const USE_NEW_PROVIDER = !!process.env.USE_NEW_PROVIDER
```

### 3. Update Model Selection

```typescript
// In src/utils/model.ts - getSlowAndCapableModel function
if (USE_NEW_PROVIDER) {
  return config.newProvider
}
```

### 4. Add Client Initialization

```typescript
// In src/services/claude.ts - getAnthropicClient function
if (USE_NEW_PROVIDER) {
  const client = new NewProviderClient(newProviderArgs)
  anthropicClient = client
  return client
}
```

## Debugging Tools

| Technique | Description |
|-----------|-------------|
| `resetAnthropicClient()` | Reset the client to force recreation |
| `process.env.API_TIMEOUT_MS` | Set a custom timeout for API calls |
| `logEvent('tengu_api_query', {...})` | Log API query events |

## Common Workflows

### 1. Model Selection During Onboarding

```mermaid
flowchart TD
    Start([Onboarding Start]) --> ConfigStep[Model Config Step]
    ConfigStep --> ShowModels[Display Available Models]
    ShowModels --> ModelSelection[User Selects Model]
    ModelSelection --> ApiKeyInput[User Inputs API Key]
    ApiKeyInput --> ValidateKey[Validate API Key]
    ValidateKey --> SaveConfig[Save to Global Config]
    SaveConfig --> NextStep[Continue Onboarding]
```

### 2. Conversation with Tool Use

```mermaid
flowchart TD
    Start([Start Conversation]) --> UserInput[User Input]
    UserInput --> Query[Call query() function]
    Query --> ModelResponse[Get Model Response]
    ModelResponse --> CheckTools{Contains tool_use?}
    
    CheckTools -- No --> DisplayResponse[Display Response]
    CheckTools -- Yes --> RunTools[Execute Tool]
    
    RunTools --> ToolResults[Get Tool Results]
    ToolResults --> RecursiveQuery[Call query() with Results]
    RecursiveQuery --> DisplayResponse
    
    DisplayResponse --> End([End Turn])
```

### 3. API Key Management

```mermaid
flowchart TD
    Start([API Key Request]) --> GetConfig[Get Global Config]
    GetConfig --> CheckConfigKey{config.apiKey set?}
    
    CheckConfigKey -- Yes --> UseConfigKey[Use config.apiKey]
    CheckConfigKey -- No --> CheckPrimaryKey{primaryApiKey set?}
    
    CheckPrimaryKey -- Yes --> UsePrimaryKey[Use primaryApiKey]
    CheckPrimaryKey -- No --> CheckEnvKey{ENV key approved?}
    
    CheckEnvKey -- Yes --> UseEnvKey[Use ENV key]
    CheckEnvKey -- No --> ReturnNull[Return null]
``` 