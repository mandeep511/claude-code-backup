# OpenAGI Model Architecture Documentation

This directory contains comprehensive documentation about the model selection and conversation management system in OpenAGI.

## Documentation Overview

The documentation is organized into the following sections:

1. **[Model Architecture Overview](./model-architecture-overview.md)** - High-level overview of the entire system
2. **[Model Selection](./model-selection.md)** - Details about model configuration and selection
3. **[Conversation Flow](./conversation-flow.md)** - Explanation of the conversation management system
4. **[API Integration](./api-integration.md)** - Information about third-party API integration
5. **[Developer Quick Reference](./developer-reference.md)** - Quick guide for developers

## Diagrams

The documentation includes Mermaid diagrams to visualize the system architecture and workflows. These can be viewed directly in GitHub or any Markdown viewer that supports Mermaid diagrams.

## Key Components

The model architecture consists of several key components:

- **Model Configuration** - Defines available models and their settings
- **API Key Management** - Securely handles authentication with model providers
- **Client Initialization** - Creates and manages provider-specific clients
- **Conversation Management** - Handles message flow and maintains conversation state
- **UI Components** - Allows users to configure and interact with models

## Extending the System

The documentation includes detailed instructions for extending the system to support additional model providers in the [API Integration](./api-integration.md) document.

## Directory Structure

The relevant code is primarily located in:

- `src/utils/model.ts` - Model configuration and selection
- `src/utils/config.ts` - Configuration management including API keys
- `src/services/claude.ts` - Anthropic client initialization and API communication
- `src/query.ts` - Conversation flow and management 