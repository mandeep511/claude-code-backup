/**
 * Constants related to product information
 */

/**
 * The name of the product/application
 */
export const PRODUCT_NAME = 'OpenAGI'
export const PRODUCT_URL = 'https://docs.anthropic.com/s/claude-code'
