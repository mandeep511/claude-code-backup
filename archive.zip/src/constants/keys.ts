export const SENTRY_DSN =
  'https://e531a1d9ec1de9064fae9d4affb0b0f4@o1158394.ingest.us.sentry.io/4508259541909504'

export const STATSIG_CLIENT_KEY =
  'client-RRNS7R65EAtReO5XA4xDC3eU6ZdJQi6lLEP6b5j32Me'
