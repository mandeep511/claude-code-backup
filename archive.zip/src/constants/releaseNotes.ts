// Release notes for each version
// Don't add more than 3 for any version, since these show up in the UI upon launch.
export const RELEASE_NOTES: Record<string, string[]> = {
  '0.1.178': [
    "New release notes now show you what's changed since you last launched",
  ],
}
