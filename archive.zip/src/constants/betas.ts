export const GATE_TOKEN_EFFICIENT_TOOLS = 'tengu-token-efficient-tools'
export const BETA_HEADER_TOKEN_EFFICIENT_TOOLS =
  'token-efficient-tools-2024-12-11'
export const GATE_USE_EXTERNAL_UPDATER = 'tengu-use-external-updater'
export const CLAUDE_CODE_20250219_BETA_HEADER = 'claude-code-20250219'
